package com.grocery.billingcalculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

/**
 * Grocery Billing Calculator
 * Accepts two numbers and performs +, -, x, / using button click listeners.
 * Shows a Toast if any input field is empty.
 */
public class MainActivity extends AppCompatActivity {

    private EditText etFirst, etSecond;
    private TextView tvResult;
    private Button btnAdd, btnSub, btnMul, btnDiv, btnClear;

    // Show up to 2 decimals, drop trailing zeros (e.g. 12.50 -> 12.5, 10.00 -> 10)
    private final DecimalFormat formatter =
            new DecimalFormat("#,##0.##", DecimalFormatSymbols.getInstance(Locale.US));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etFirst = findViewById(R.id.etFirst);
        etSecond = findViewById(R.id.etSecond);
        tvResult = findViewById(R.id.tvResult);
        btnAdd = findViewById(R.id.btnAdd);
        btnSub = findViewById(R.id.btnSub);
        btnMul = findViewById(R.id.btnMul);
        btnDiv = findViewById(R.id.btnDiv);
        btnClear = findViewById(R.id.btnClear);

        // Event listeners on the operation buttons
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculate('+');
            }
        });

        btnSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculate('-');
            }
        });

        btnMul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculate('*');
            }
        });

        btnDiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculate('/');
            }
        });

        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etFirst.setText("");
                etSecond.setText("");
                tvResult.setText(R.string.result_default);
                etFirst.requestFocus();
            }
        });
    }

    private void calculate(char operation) {
        String first = etFirst.getText().toString().trim();
        String second = etSecond.getText().toString().trim();

        // Validation: any empty field -> Toast
        if (first.isEmpty() || second.isEmpty()) {
            Toast.makeText(this, R.string.msg_empty, Toast.LENGTH_SHORT).show();
            return;
        }

        double a, b;
        try {
            a = Double.parseDouble(first);
            b = Double.parseDouble(second);
        } catch (NumberFormatException e) {
            Toast.makeText(this, R.string.msg_invalid, Toast.LENGTH_SHORT).show();
            return;
        }

        double result;
        switch (operation) {
            case '+':
                result = a + b;
                break;
            case '-':
                result = a - b;
                break;
            case '*':
                result = a * b;
                break;
            case '/':
                if (b == 0) {
                    Toast.makeText(this, R.string.msg_div_zero, Toast.LENGTH_SHORT).show();
                    return;
                }
                result = a / b;
                break;
            default:
                return;
        }

        tvResult.setText(formatter.format(result));
    }
}
