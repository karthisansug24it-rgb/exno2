# Grocery Billing Calculator (Android)

A simple counter-top billing calculator for a small grocery shop.

- Two number inputs
- Add, Subtract, Multiply, Divide buttons, each with its own click listener
- Layouts: nested `LinearLayout` (page and input card) and a 2 x 2 `GridLayout` (operation buttons)
- A `Toast` asks for values if either field is empty (also for invalid input and division by zero)

## Run it

**Option A - one click (Windows):** double-click `run_app.bat`.
It finds Java and the Android SDK, starts an emulator if no phone is connected, builds, installs and launches the app.

**Option B - Android Studio:** File > Open > select this folder, wait for Gradle sync, press Run.

Requirements: Android Studio (Hedgehog or newer, bundled JDK 17) and internet on the first build.

## Project layout

```
app/src/main/java/com/grocery/billingcalculator/MainActivity.java
app/src/main/res/layout/activity_main.xml
app/src/main/res/values/  (strings, colors, themes)
run_app.bat
```
