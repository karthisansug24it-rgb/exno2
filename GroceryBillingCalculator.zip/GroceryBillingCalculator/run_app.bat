@echo off
setlocal EnableDelayedExpansion
title Grocery Billing Calculator - Build and Run
cd /d "%~dp0"

echo ==================================================
echo   Grocery Billing Calculator - Build and Run
echo ==================================================
echo.

rem ---------- 1. Find Java 17 (Android Studio's bundled JDK is preferred) ----------
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\java.exe" goto java_ok
set "JAVA_HOME="
for %%P in ("%ProgramFiles%\Android\Android Studio\jbr" "%LOCALAPPDATA%\Programs\Android Studio\jbr" "%ProgramFiles%\Android\Android Studio Preview\jbr") do (
    if exist "%%~P\bin\java.exe" if not defined JAVA_HOME set "JAVA_HOME=%%~P"
)
if defined JAVA_HOME goto java_ok
where java >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Java not found. Install Android Studio or JDK 17 and set JAVA_HOME.
    pause
    exit /b 1
)
:java_ok
if defined JAVA_HOME set "PATH=%JAVA_HOME%\bin;%PATH%"
echo [OK] Java ready.

rem ---------- 2. Find Android SDK ----------
set "SDK="
if defined ANDROID_HOME if exist "%ANDROID_HOME%\platform-tools\adb.exe" set "SDK=%ANDROID_HOME%"
if not defined SDK if defined ANDROID_SDK_ROOT if exist "%ANDROID_SDK_ROOT%\platform-tools\adb.exe" set "SDK=%ANDROID_SDK_ROOT%"
if not defined SDK if exist "%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe" set "SDK=%LOCALAPPDATA%\Android\Sdk"
if not defined SDK (
    echo [ERROR] Android SDK not found. Install it through Android Studio, or set ANDROID_HOME.
    pause
    exit /b 1
)
echo [OK] Android SDK: %SDK%

rem Tell Gradle where the SDK is (local.properties is machine-specific)
set "SDK_FWD=%SDK:\=/%"
>"local.properties" echo sdk.dir=%SDK_FWD%

set "PATH=%SDK%\platform-tools;%SDK%\emulator;%PATH%"

rem ---------- 3. Find a connected phone / running emulator ----------
adb start-server >nul 2>&1
set "DEVICE="
for /f "skip=1 tokens=1,2" %%A in ('adb devices') do (
    if "%%B"=="device" if not defined DEVICE set "DEVICE=%%A"
)

if defined DEVICE (
    echo [OK] Device found: %DEVICE%
    set "ANDROID_SERIAL=%DEVICE%"
    goto build
)

rem ---------- 4. No device: start the first available emulator ----------
echo No device connected. Looking for an emulator...
set "AVD="
for /f "delims=" %%A in ('emulator -list-avds 2^>nul') do (
    echo %%A| findstr /b /c:"INFO" /c:"WARNING" >nul
    if errorlevel 1 if not defined AVD set "AVD=%%A"
)
if not defined AVD (
    echo [ERROR] No phone or emulator available.
    echo   - Connect a phone with USB debugging ON, or
    echo   - Create an emulator in Android Studio: Tools ^> Device Manager.
    pause
    exit /b 1
)

echo Starting emulator: %AVD%
start "" emulator -avd "%AVD%"
adb wait-for-device
set "BOOT="
set /a TRIES=0
:wait_boot
set /a TRIES+=1
for /f "tokens=*" %%B in ('adb shell getprop sys.boot_completed 2^>nul') do set "BOOT=%%B"
if "!BOOT!"=="1" goto build
if !TRIES! GEQ 60 (
    echo [ERROR] Emulator took too long to start.
    pause
    exit /b 1
)
timeout /t 3 /nobreak >nul
goto wait_boot

rem ---------- 5. Build, install and launch ----------
:build
echo.
echo Building and installing the app. The first run downloads Gradle, so please wait...
call gradlew.bat installDebug
if errorlevel 1 (
    echo.
    echo [ERROR] Build failed. Check the messages above.
    pause
    exit /b 1
)

echo.
echo Launching the app...
adb shell am start -n com.grocery.billingcalculator/.MainActivity

echo.
echo Done! The Grocery Billing Calculator is running.
pause
endlocal
